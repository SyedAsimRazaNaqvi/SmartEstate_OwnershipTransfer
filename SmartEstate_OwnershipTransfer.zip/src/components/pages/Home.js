import React from 'react'
import TransferInfo from '../TransferInfo'

function Home() {
  return (
    <div >
      <h1>Welcome to Home page</h1>

      {/* <TransferInfo  /> */}
    </div>
  );
}

export default Home;