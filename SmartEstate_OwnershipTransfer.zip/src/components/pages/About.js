import React from 'react';
// import OfferStatus from '../OfferStatus';
import DeveloperSection from '../About/DeveloperSection'

import AboutSmartEstate from '../About/about-smartestate'

const about = () => {
    return (
      <>
      <AboutSmartEstate/>
<DeveloperSection/>
      </>
    );
  }
  
  export default about;